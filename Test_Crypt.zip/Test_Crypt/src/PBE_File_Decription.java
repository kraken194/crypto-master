//
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import javax.crypto.Cipher;
//import javax.crypto.SecretKey;
//import javax.crypto.SecretKeyFactory;
//import javax.crypto.spec.PBEKeySpec;
//import javax.crypto.spec.PBEParameterSpec;
//
//
//public class PBE_File_Decription {
//    // Добавить передачу данных с мейн мегакрипт
//
//    public static void main(String[] args) throws Exception {
//
//        FileInputStream inFile = new FileInputStream("PBE_Cripted_File.des");
//        FileOutputStream outFile = new FileOutputStream("PBE_decrypted.txt");
//
//        String password = "javapapers";
//        PBEKeySpec pbeKeySpec = new PBEKeySpec(password.toCharArray());
//        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("PBEWithMD5AndTripleDES");
//        SecretKey secretKey = secretKeyFactory.generateSecret(pbeKeySpec);
//
//        byte[] salt = new byte[8];
//        inFile.read(salt);
//        
//        PBEParameterSpec pbeParameterSpec = new PBEParameterSpec(salt, 100);
//        Cipher cipher = Cipher.getInstance("PBEWithMD5AndTripleDES");
//        cipher.init(Cipher.DECRYPT_MODE, secretKey, pbeParameterSpec);
//
//        byte[] in = new byte[64];
//        int bytesRead;
//        while ((bytesRead = inFile.read(in)) != -1) {
//            byte[] output = cipher.update(in, 0,  bytesRead);
//            if (output != null) {
//                outFile.write(output);
//            }
//        }
//
//        byte[] output = cipher.doFinal();
//        if (output != null) {
//            outFile.write(output);
//        }
//
//        inFile.close();
//        outFile.flush();
//        outFile.close();
//        System.out.println("PBE File Decrypted.");
//    }
//}