//
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.util.Random;
//import javax.crypto.Cipher;
//import javax.crypto.SecretKey;
//import javax.crypto.SecretKeyFactory;
//import javax.crypto.spec.PBEKeySpec;
//import javax.crypto.spec.PBEParameterSpec;
//
//public class PBE_File_Encription{    
//// https://javapapers.com/java/java-file-encryption-decryption-using-password-based-encryption-pbe/
//// FileEncryption.java
//// в папку мегакрипта
//       
//    public static void main(String[] args) throws Exception {
//        
//        
//        //Узнаем время работы программы
//        long startTime = System.currentTimeMillis();
//
//        FileInputStream inFile = new FileInputStream(args[0]); // "C:\\Users\\User\\Desktop\\курсач\\new.txt" тестовый путь
//        FileOutputStream outFile = new FileOutputStream("PBE_Cripted_File.des");
//
//        String password = "javapapers";
//        PBEKeySpec pbeKeySpec = new PBEKeySpec(password.toCharArray());
//        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("PBEWithMD5AndTripleDES");
//        SecretKey secretKey = secretKeyFactory.generateSecret(pbeKeySpec);
//
//        byte[] salt = new byte[8];
//        Random random = new Random();
//        random.nextBytes(salt);
//
//        PBEParameterSpec pbeParameterSpec = new PBEParameterSpec(salt, 100);
//        Cipher cipher = Cipher.getInstance("PBEWithMD5AndTripleDES");
//        cipher.init(Cipher.ENCRYPT_MODE, secretKey, pbeParameterSpec);
//        outFile.write(salt);
//
//        byte[] input = new byte[64];
//        int bytesRead;
//        while ((bytesRead = inFile.read(input)) != -1) {
//            byte[] output = cipher.update(input, 0, bytesRead);
//            if (output != null) {
//                outFile.write(output);
//            }
//        }
//
//        byte[] output = cipher.doFinal();
//        if (output != null) {
//            outFile.write(output);
//        }
//
//        inFile.close();
//        outFile.flush();
//        outFile.close();
//        System.out.println("PBE File Encrypted.");
//        
//        long timeSpent = System.currentTimeMillis() - startTime;
//        System.out.println("PBE программа выполнялась " + timeSpent + " миллисекунд");
//        
//        // устанавливаем время в лейбл
//        
//        //MainMegacript mm = new MainMegacript();
////        mm.setVisible(true);
////        mm.pack();
////        mm.setLocationRelativeTo(null);
////        mm.jLabel_PBE_TIME_.setText("xui");
//        //mm.setExtendedState(JFrame.MAXIMIZED_BOTH);
//        //mm.jLabel_PBE_TIME_.setText("программа выполнялась " + timeSpent + " миллисекунд");
//        
//    }
//}
